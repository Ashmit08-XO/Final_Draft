from rest_framework.views import APIView
from rest_framework.response import Response
from .services import find_optimal_hospital

class OptimalHospitalView(APIView):
    def get(self, request):
        user_lat = request.query_params.get('lat')
        user_lng = request.query_params.get('lng')
        
        hospital, duration = find_optimal_hospital(user_lat, user_lng)
        
        return Response({
            'hospital': {
                'id': hospital.id,
                'name': hospital.name,
                'address': hospital.address,
                'location': {
                    'lat': float(hospital.latitude),
                    'lng': float(hospital.longitude)
                }
            },
            'eta_seconds': duration,
            'eta_minutes': round(duration / 60, 1)
        })