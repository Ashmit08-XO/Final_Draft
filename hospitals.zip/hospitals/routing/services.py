from hospitals.models import Hospital
from hospitals.utils.ors import ORSClient

def find_optimal_hospital(user_lat, user_lng):
    """Finds hospital with fastest route using ORS Matrix"""
    hospitals = Hospital.objects.all()
    ors = ORSClient()
    
    # Prepare locations: [user, hosp1, hosp2...]
    locations = [[user_lng, user_lat]]  # ORS uses [lng,lat]
    for hospital in hospitals:
        locations.append([float(hospital.longitude), float(hospital.latitude)])
    
    # Get travel times
    matrix = ors.get_matrix(locations)
    durations = matrix['durations'][0][1:]  # Skip user→user
    
    # Find fastest hospital
    fastest_idx = durations.index(min(durations))
    return hospitals[fastest_idx], durations[fastest_idx]