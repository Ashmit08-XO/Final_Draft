import requests
from django.conf import settings

class ORSClient:
    BASE_URL = "https://api.openrouteservice.org/v2"
    
    def __init__(self):
        self.api_key = settings.ORS_API_KEY
    
    def get_matrix(self, locations, profile='driving-car'):
        """Call ORS Matrix API"""
        url = f"{self.BASE_URL}/matrix/{profile}"
        headers = {
            'Authorization': self.api_key,
            'Content-Type': 'application/json'
        }
        payload = {
            "locations": locations,
            "metrics": ["distance", "duration"],
            "units": "km"
        }
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()