from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .serializers import (
    HospitalRegistrationSerializer,
    HospitalLoginSerializer,
    HospitalProfileSerializer
)
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Hospital

def get_tokens_for_hospital(hospital):
    refresh = RefreshToken.for_user(hospital)
    
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

class HospitalRegistrationView(APIView):
    def post(self, request):
        serializer = HospitalRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            hospital = serializer.save()
            token = get_tokens_for_hospital(hospital)
            return Response({'token': token, 'message': 'Registration successful'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class HospitalLoginView(APIView):
    def post(self, request):
        serializer = HospitalLoginSerializer(data=request.data)
        if serializer.is_valid():
            hospital = serializer.validated_data
            token = get_tokens_for_hospital(hospital)
            return Response({'token': token, 'message': 'Login successful'}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class HospitalProfileView(generics.RetrieveAPIView):
    serializer_class = HospitalProfileSerializer
    permission_classes = [IsAuthenticated]
    
    def get_object(self):
        return self.request.user
    


class HospitalListView(APIView):
    def get(self, request):
        hospitals = Hospital.objects.all()
        serializer = HospitalProfileSerializer(hospitals, many=True)
        return Response(serializer.data)    


# views.py
class HospitalLoginView(APIView):
    def post(self, request):
        serializer = HospitalLoginSerializer(data=request.data)
        if serializer.is_valid():
            hospital = serializer.validated_data
            token = get_tokens_for_hospital(hospital)
            return Response({
                'token': token,
                'message': 'Login successful',
                'hospital_id': hospital.id,  # Add hospital ID to response
                'name': hospital.name      # Add hospital name
            }, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# views.py
class HospitalDetailView(generics.RetrieveAPIView):
    serializer_class = HospitalProfileSerializer
    permission_classes = [IsAuthenticated]
    queryset = Hospital.objects.all()
    lookup_field = 'id'                