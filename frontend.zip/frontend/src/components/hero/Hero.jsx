// import React, { useState } from 'react'
// import "./Hero.css"
// import MapModal from '../map/MapModal'

// function Hero() {
//   const [showSiren, setShowSiren] = useState(false)
//   const [showMap, setShowMap] = useState(false)

//   const handleEmergency = () => {
//     // Show siren
//     setShowSiren(true)

//     // After 2 seconds, hide siren and show map
//     setTimeout(() => {
//       setShowSiren(false)
//       setShowMap(true)
//     }, 2000)
//   }

//   return (
//     <div className="hero">
//       <h1 className='hero-heading'>For Emergency Click the below button</h1>
//       <h6 className='hero-h6'>Disclaimer! ,Dont click unnessarily on the button</h6>
//       <button className='btn' onClick={handleEmergency}>Emergency</button>

//       {showSiren && (
//   <div className="ambulance-siren">
//     <div className="light red-light"></div>
//     <div className="light blue-light"></div>
//   </div>
// )}

//       {showMap && <MapModal onClose={() => setShowMap(false)} />}
//     </div>
//   )
// }

// export default Hero
import React, { useState } from 'react'
import "./Hero.css"
import MapModal from '../map/MapModal'

function Hero() {
  const [showSiren, setShowSiren] = useState(false)
  const [showMap, setShowMap] = useState(false)
  const [btnClicked, setBtnClicked] = useState(false)

  const handleEmergency = () => {
    setBtnClicked(true)
    setShowSiren(true)

    setTimeout(() => {
      setShowSiren(false)
      setShowMap(true)
      setBtnClicked(false)
    }, 2500)
  }

  return (
    <div className="hero">
      <h1 className="hero-heading">For Emergency Click the Button Below</h1>
      <h6 className="hero-h6">Disclaimer: Don't click unnecessarily</h6>

      <button
        className={`btn ${btnClicked ? 'btn-pulse' : ''}`}
        onClick={handleEmergency}
        disabled={btnClicked}
      >
        Emergency
      </button>

      {showSiren && (
        <div className="ambulance-siren">
          <div className="light red-light"></div>
          <div className="light blue-light"></div>
        </div>
      )}

      {showMap && <MapModal onClose={() => setShowMap(false)} />}
    </div>
  )
}

export default Hero