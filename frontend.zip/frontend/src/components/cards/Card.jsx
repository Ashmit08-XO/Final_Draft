// import React from 'react'
// import "./card.css"
// import card1 from "../../assets/card1.jpg"
// function Card() {
//   return (
//     <div className='cards'>
//      <div className="content">Write about something</div>
//      <div className="content-img"> <img src={card1} /></div>
//     </div>
//   )
// }

// export default Card
// CardSection.jsx
// CardSection.jsx
import React from 'react';
import './card.css';
import Img1 from '../../assets/img1.jpg';
import Img2 from '../../assets/img2.jpg';
import Img3 from '../../assets/img3.jpg';
import Img4 from '../../assets/img4.jpg';

const cards = [
  {
    title: 'In Case of accidents ',
    description: 'Click on emergency Button ,which will help to call ambulance quickly and also get the bed reserved at Hospital',
    image: Img1,
  },
  {
    title: 'Arrival of Ambulance',
    description: 'The Ambulance which is going to arrive in the accidental spot will opt the fastest and best route for time management',
    image: Img2,
  },
  {
    title: 'Reserved Bed for Patient',
    description: 'Along with quick ambulance there will be a bed reserved for patient in the registered Hospital which will help in quick treatment for patient',
    image: Img3,
  },
  {
    title: 'Hospital Routing',
    description: 'When the request is accepted then on user interface there will be a map displaying ,by that one can track the ambulance',
    image: Img4,
  },
];

const CardSection = () => {
  return (
    <div className="card-section">
      {cards.map((card, index) => (
        <div className={`card ${index % 2 === 1 ? 'reverse' : ''}`} key={index}>
          <img src={card.image} alt={card.title} className="card-img" />
          <div className="card-info">
            <h3 className='card-title'>{card.title}</h3>
            <p className='card-para'>{card.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CardSection;