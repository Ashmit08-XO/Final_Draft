import React from 'react'
import "./Navbar.css"
import {Link} from 'react-router-dom';

function Navbar() {
  return (
    <nav>
        <h1 className='heading'>Health Care</h1>
        <h1></h1>
        <ul className='navbar-ul'>
            <li ><Link to='/login' className='log'>Login</Link></li>
            <li> <Link to='/about' className='abt'>About</Link></li>
            <li><Link to='/help' className='help'>Help</Link></li>
        </ul>
    </nav>
  )
}

export default Navbar