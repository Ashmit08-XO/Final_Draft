import React from 'react'
import "./Footer.css"
function Footer() {
  return (
    <div className='footer'>
        <ul className='footer-ul'>
            <li><a href='#'>Terms & Conditions</a></li>
            <li><a href='#'>Privacy Policy</a></li>
            <li><a href='#'>Notice of Privacy Practices</a></li>
            <li><a href='#'>Accessibility Statement</a></li>
            <li><a href='#'>Advertising & sponsorship Policy </a></li>
            <li><a href='#'>Site Map</a></li>
        
        </ul>

        <p>&copy; 1998-2025 All rughts reserved</p>
    </div>
  )
}

export default Footer