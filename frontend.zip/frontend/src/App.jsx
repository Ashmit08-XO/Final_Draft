import React from 'react'
import "./App.css"
import Navbar from './components/navbar/Navbar'
import Hero from './components/hero/Hero'
// import Footer from './components/Footer/Footer'
import Footer from './components/footer/Footer'
import { BrowserRouter as  Router,Routes,Route } from 'react-router-dom'
import Login from './pages/login/Login'
import About from './pages/about/About'
import Card from './components/cards/Card'
import Help from './pages/help/Help'
function App() {
  return (
    <>
  

    <Router>
    <Navbar/>
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path="/about" element={<About/>}/>
        <Route path="/help" element={<Help/>}/>
      </Routes>
    </Router>
    
    <div className="app-cards">
    <Hero/>
    <Card/>
    </div>

    <Footer/>
   
    </>
  )
}

export default App