import React from 'react';
import './Help.css';

const Help = () => {
  return (
    <div className="help-div">
      <h2>How It Works</h2>
      <ol>
        <li>
          <strong>Emergency Button:</strong> When a user clicks the Emergency Button, their current location is automatically detected.
        </li>
        <li>
          <strong>Nearest Hospital Alert:</strong> A request is sent to the nearest hospitals based on the user's GPS location.
        </li>
        <li>
          <strong>Hospital Acceptance:</strong> Hospitals with availability receive the alert and can choose to accept the emergency request.
        </li>
        <li>
          <strong>Ambulance Dispatched:</strong> Once accepted, an ambulance is dispatched immediately to the user’s location.
        </li>
        <li>
          <strong>Live Tracking:</strong> The user can view the ambulance approaching in real-time on a map.
        </li>
        <li>
          <strong>Bed Reservation:</strong> Simultaneously, a bed is reserved for the patient at the accepting hospital.
        </li>
        <li>
          <strong>Receptionist Interface:</strong> The hospital staff manage the request, track the ambulance, and prepare for the patient's arrival.
        </li>
      </ol>
      <p>
        Our goal is to reduce delays in emergency response and save lives through fast, tech-driven coordination between users and hospitals.
      </p>
    </div>
  );
};

export default Help;