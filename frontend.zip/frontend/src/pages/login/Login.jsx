// src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import "./Login.css"
const Login = () => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [token, setToken] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:8000/api/hospital/login/', {
        name,
        password
      });

      const { token, message } = res.data;
      setToken(token.access);
      setMessage(message);
      localStorage.setItem('accessToken', token.access);
    } catch (err) {
      setMessage('Login failed: ' + err.response.data?.detail || 'Invalid credentials');
    }
  };

  return (
    <div className='login-div'>
      <h2 className='login-h1'>Hospital Login</h2>
      <form onSubmit={handleLogin}>
        <input
          type="text"
          placeholder="Hospital Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        /><br /><br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        /><br /><br />
        <button className='login-btn' type="submit">Login</button>
      </form>
      {message && <p>{message}</p>}
      {token && <p style={{ fontSize: '0.8rem' }}>Access Token stored in localStorage ✅</p>}
    </div>
  );
};

export default Login;
