import React from 'react'
import "./About.css"
function About() {
  return (
    <div className="abt-div">
    <h2>About Us</h2>
    <p>
      In critical moments, every second counts. Our platform is designed to provide
      <strong> instant emergency support </strong> by connecting patients to the
      <strong> nearest hospitals </strong> with just a single click.
    </p>
    <ul>
      <li>Instantly send an emergency alert with your <span className="highlight">live location</span>.</li>
      <li>Connect with the <span className="highlight">nearest available hospital</span>.</li>
      <li>Receive <span className="highlight">real-time confirmation</span> from hospitals.</li>
      <li>Track the ambulance using a <span className="highlight">live map</span>.</li>
      <li>Ensure <span className="highlight">advance bed reservation</span>.</li>
    </ul>
    <p>
      Our mission is to <strong>save lives</strong> by reducing emergency response time
      through smart, connected technology.
    </p>
    <p>
      This system also features a <strong>hospital receptionist interface</strong> for real-time request management and ambulance coordination.
    </p>
  </div>
  )
}

export default About